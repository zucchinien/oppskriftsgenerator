const recipes = [
    {
        title: "Middelhavsk Quinoa-bolle",
        cuisine: "Middelhavskjøkken",
        prepTime: "25 minutter",
        ingredients: [
            "1 kopp quinoa",
            "2 kopper vann",
            "1 boks kikerter, avrent",
            "1 agurk, i terninger",
            "2 tomater, i terninger",
            "1 rødløk, finhakket",
            "1/2 kopp Kalamata-oliven",
            "1/2 kopp fetaost",
            "2 ss olivenolje",
            "1 sitron, presset",
            "Fersk persille og mynte",
            "Salt og pepper etter smak"
        ],
        instructions: [
            "Kok quinoa i vann etter pakkeinstruksjonene",
            "Mens quinoa koker, forbered grønnsakene",
            "I en stor bolle, kombiner kokt quinoa med grønnsaker",
            "Tilsett kikerter og oliven",
            "Dress med olivenolje og sitronsaft",
            "Krydre med salt og pepper",
            "Topp med fetaost og ferske urter"
        ]
    },
    {
        title: "Grønnsaksenchiladas",
        cuisine: "Meksikansk",
        prepTime: "30 minutter",
        ingredients: [
            "8 maislefser",
            "2 kopper svarte bønner",
            "1 paprika, i terninger",
            "1 løk, i terninger",
            "1 squash, i terninger",
            "2 kopper enchiladasaus",
            "1 kopp revet ost",
            "1 ts kummin",
            "1 ts chilipulver",
            "Salt og pepper etter smak"
        ],
        instructions: [
            "Forvarm ovnen til 375°F (190°C)",
            "Fres grønnsakene med krydder til de er myke",
            "Bland grønnsaker med svarte bønner",
            "Fyll lefsene med blandingen og rull sammen",
            "Legg i ildfast form",
            "Topp med enchiladasaus og ost",
            "Stek i 20 minutter"
        ]
    },
    {
        title: "Spinat og Ricotta Cannelloni",
        cuisine: "Italiensk",
        prepTime: "30 minutter",
        ingredients: [
            "12 ferske lasagneplater",
            "500g ricottaost",
            "300g spinat",
            "1 egg",
            "Muskatnøtt",
            "Salt og pepper",
            "Tomatpuré",
            "Mozzarellaost",
            "Fersk basilikum"
        ],
        instructions: [
            "Bland ricotta, spinat, egg og muskatnøtt",
            "Krydre med salt og pepper",
            "Fordel blandingen på lasagneplatene",
            "Rull til cannelloni",
            "Legg i ildfast form",
            "Dekk med tomatpuré",
            "Topp med mozzarella",
            "Stek i 20 minutter"
        ]
    },
    {
        title: "Grønnsakscurry",
        cuisine: "Indisk",
        prepTime: "25 minutter",
        ingredients: [
            "1 løk, i terninger",
            "2 fedd hvitløk, finhakket",
            "1 ss currypulver",
            "1 ts kummin",
            "1 ts gurkemeie",
            "1 boks kokosmelk",
            "2 kopper blandede grønnsaker",
            "1 kopp kikerter",
            "Fersk koriander",
            "Ris til servering"
        ],
        instructions: [
            "Fres løk og hvitløk",
            "Tilsett krydder og stek til duften er god",
            "Tilsett grønnsaker og kikerter",
            "Hell i kokosmelk",
            "La småkoke til grønnsakene er myke",
            "Server med ris og fersk koriander"
        ]
    },
    {
        title: "Gresk Salatbolle",
        cuisine: "Middelhavskjøkken",
        prepTime: "20 minutter",
        ingredients: [
            "2 kopper kokt bulgur",
            "1 agurk, i terninger",
            "2 tomater, i terninger",
            "1 rødløk, i skiver",
            "1/2 kopp Kalamata-oliven",
            "1/2 kopp fetaost",
            "2 ss olivenolje",
            "1 sitron, presset",
            "Tørket oregano",
            "Salt og pepper"
        ],
        instructions: [
            "Kok bulgur etter pakkeinstruksjonene",
            "Bland alle grønnsaker i en bolle",
            "Tilsett oliven og feta",
            "Dress med olivenolje og sitronsaft",
            "Krydre med oregano, salt og pepper",
            "Server varm eller kald"
        ]
    },
    {
        title: "Vegetarisk Pad Thai",
        cuisine: "Thai",
        prepTime: "25 minutter",
        ingredients: [
            "200g risnudler",
            "2 ss olivenolje",
            "2 egg",
            "1/2 kopp tofu, i terninger",
            "1 gulrot, i strimler",
            "1/2 kopp bønnespirer",
            "2 ss fiskesaus",
            "1 ss tamarindpuré",
            "1/2 kopp mandler, hakket",
            "Fersk koriander og lime"
        ],
        instructions: [
            "Kok risnudlene etter pakkeinstruksjonene",
            "Stek tofu i olje til gyllen",
            "Tilsett egg og stek",
            "Tilsett grønnsaker og nudler",
            "Bland inn saus",
            "Topp med mandler og ferske urter"
        ]
    },
    {
        title: "Vegetarisk Lasagne",
        cuisine: "Italiensk",
        prepTime: "30 minutter",
        ingredients: [
            "12 lasagneplater",
            "500g ricottaost",
            "300g spinat",
            "1 løk, hakket",
            "2 fedd hvitløk, hakket",
            "1 boks tomatpuré",
            "1 kopp revet mozzarella",
            "1 kopp melk",
            "2 ss olivenolje",
            "Salt og pepper"
        ],
        instructions: [
            "Forvarm ovnen til 180°C",
            "Fres løk og hvitløk",
            "Bland ricotta og spinat",
            "Lag lag med lasagneplater, fyll og saus",
            "Topp med ost",
            "Stek i 30 minutter"
        ]
    },
    {
        title: "Vegetarisk Tacos",
        cuisine: "Meksikansk",
        prepTime: "25 minutter",
        ingredients: [
            "8 tacoskjell",
            "400g svarte bønner",
            "1 paprika, i strimler",
            "1 løk, hakket",
            "1 tomat, hakket",
            "1 avokado",
            "1/2 kopp maiss",
            "1/2 kopp revet ost",
            "1 ts kummin",
            "1 ts chilipulver"
        ],
        instructions: [
            "Varm tacoskjellene",
            "Stek grønnsaker med krydder",
            "Varm bønnene",
            "Lag guacamole av avokado",
            "Fyll tacoskjellene",
            "Topp med ost og maiss"
        ]
    }
]; 