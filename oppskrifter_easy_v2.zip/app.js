function createIngredientElement(ingredient) {
    return `<li>${ingredient}</li>`;
}

function generateRecipe() {
    const recipeCard = document.getElementById('recipeCard');
    const randomRecipe = recipes[Math.floor(Math.random() * recipes.length)];
    
    // Remove active class to trigger animation
    recipeCard.classList.remove('active');
    
    // Update content after a short delay to allow animation to play
    setTimeout(() => {
        // Update recipe title and meta information
        document.querySelector('.recipe-title').textContent = randomRecipe.title;
        document.querySelector('.prep-time').textContent = `Tilberedningstid: ${randomRecipe.prepTime}`;
        document.querySelector('.recipe-cuisine').textContent = randomRecipe.cuisine;
        
        // Update ingredients list
        const ingredientsList = document.querySelector('.ingredients');
        ingredientsList.innerHTML = randomRecipe.ingredients
            .map(ingredient => createIngredientElement(ingredient))
            .join('');
        
        // Update instructions list
        const instructionsList = document.querySelector('.instructions');
        instructionsList.innerHTML = randomRecipe.instructions
            .map(instruction => `<li>${instruction}</li>`)
            .join('');
        
        // Add active class to trigger animation
        recipeCard.classList.add('active');
    }, 300);
}

// Generate first recipe when page loads
document.addEventListener('DOMContentLoaded', generateRecipe); 